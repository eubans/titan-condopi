
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                
                <div class="page-content libre-franklin-regular">
                    <div class="left_alain_top plans_and_pricing">
                        <h2 class="heading-title">You have updated your account successfully.</h2>
                        
                        <p>Start date: <?php echo date("Y-m-d"); ?></p>
                        <p>End date: <?php echo $member_subscription_current['Expiry_Date']; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>