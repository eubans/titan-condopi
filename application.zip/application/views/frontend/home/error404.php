<style>
	.page .section-body{background:#FFF!important;}
</style>