
<div class="widget">
	<ul class="side-nav-list">
		<li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/profile/send_mail_client">Send mail to client</a></li>
		<li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/profile/">Edit Profile</a></li>
	    <li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/members">All Profiles</a></li>
		<li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/listings">All Listings</a></li>
	    <li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/listings/addlisting">New Listing</a></li>
	    <li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/profile/change_password">Change Password</a></li>
	    <li><a class="side-nav-item" href="<?php echo base_url(); ?>admin/profile/logout">Log Out</a></li>
	</ul>
</div>