<?php /* <p>STEP 1: Enter all required fields.</p>
<p>STEP 2: Email property photos (7 photos maximum) to: photos@Condo PI<p>
<p>STEP 3: Wait for offers. If you do not receive any offers during the 7 day period, you can re-list your property.<p> */ ?>