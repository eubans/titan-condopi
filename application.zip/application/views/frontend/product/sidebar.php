<div class="widget">
    <ul class="side-nav-list">
        <li><a class="side-nav-item" href="<?php echo base_url() ?>product/">Your Listings</a></li>
        <li><a class="side-nav-item" href="<?php echo base_url() ?>product/add">New Listing</a></li>
    </ul>
</div>