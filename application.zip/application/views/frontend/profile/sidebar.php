

<div class="widget">

	<ul class="side-nav-list">

		<li><a class="side-nav-item" href="<?php echo base_url() ?>profile/listing">Your Listing</a></li>

	    <li><a class="side-nav-item" href="<?php echo base_url() ?>profile/addlisting">Add Listing</a></li>

	    <li><a class="side-nav-item" href="<?php echo base_url() ?>profile/">Edit Profile</a></li>

	    <li><a class="side-nav-item" href="<?php echo base_url() ?>profile/change_password">Change Password</a></li>

	    <li><a class="side-nav-item" href="<?php echo base_url() ?>profile/logout">Logout</a></li>

	</ul>

</div>